
function switchLanguage(lang) {
    alert("Language switched to " + lang.toUpperCase());
}
function convertCurrency() {
    const currency = document.getElementById('currency').value;
    alert("Prices converted to " + currency);
}
